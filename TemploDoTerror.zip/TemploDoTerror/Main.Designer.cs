﻿namespace TemploDoTerror
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.habilidadeinicial = new System.Windows.Forms.TextBox();
            this.energiainicial = new System.Windows.Forms.TextBox();
            this.sorteinicial = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // habilidadeinicial
            // 
            this.habilidadeinicial.Location = new System.Drawing.Point(12, 37);
            this.habilidadeinicial.Name = "habilidadeinicial";
            this.habilidadeinicial.Size = new System.Drawing.Size(100, 20);
            this.habilidadeinicial.TabIndex = 2;
            this.habilidadeinicial.Text = "Habilidade";
            this.habilidadeinicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.habilidadeinicial.TextChanged += new System.EventHandler(this.habilidadeinicial_TextChanged);
            // 
            // energiainicial
            // 
            this.energiainicial.Location = new System.Drawing.Point(118, 37);
            this.energiainicial.Name = "energiainicial";
            this.energiainicial.Size = new System.Drawing.Size(100, 20);
            this.energiainicial.TabIndex = 4;
            this.energiainicial.Text = "Energia";
            this.energiainicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.energiainicial.TextChanged += new System.EventHandler(this.energiainicial_TextChanged);
            // 
            // sorteinicial
            // 
            this.sorteinicial.Location = new System.Drawing.Point(224, 37);
            this.sorteinicial.Name = "sorteinicial";
            this.sorteinicial.Size = new System.Drawing.Size(100, 20);
            this.sorteinicial.TabIndex = 6;
            this.sorteinicial.Text = "Sorte";
            this.sorteinicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.sorteinicial.TextChanged += new System.EventHandler(this.sorte_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(130, 66);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Roll Stats";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(130, 95);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Começar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "HABILIDADE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "ENERGIA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(249, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "SORTE";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 138);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.sorteinicial);
            this.Controls.Add(this.energiainicial);
            this.Controls.Add(this.habilidadeinicial);
            this.Name = "Main";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox energiainicial;
        private System.Windows.Forms.TextBox sorteinicial;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox habilidadeinicial;
    }
}

