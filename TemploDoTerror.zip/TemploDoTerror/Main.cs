﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;



namespace TemploDoTerror
{
    public partial class Main : Form
    {
        List<PassosModel> passos = new List<PassosModel>();
        public Folha _folha = new Folha();

        public Main()
        {
            InitializeComponent();
            button1.Enabled = false;
            //passos = PassosLib.Load1();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    TemploDoTerror.Controller.dice.Roll();

        //    int roll = TemploDoTerror.Controller.dice.Roll();

        //    label1.Text = roll.ToString();
        //}

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
        private string valhabilidade;
        private string valenergia;
        private string valsorte;
        public string phabilidade { get { return valhabilidade; } set {valhabilidade = value; } }

        public string penergia { get { return valenergia; } set { valenergia = value; } }

        public string psorte { get { return valsorte; } set { valsorte = value; } }

        public string _ht;
        public string _et;
        public string _st;

        private void button2_Click(object sender, EventArgs e)
        {
                
            int _habilidade = TemploDoTerror.Controller.lib.IndiceHabilidade();
            int _energia = TemploDoTerror.Controller.lib.IndiceEnergia();
            int _sorte = TemploDoTerror.Controller.lib.IndiceSorte();

            _ht = _habilidade.ToString();
            _et = _energia.ToString();
            _st = _sorte.ToString();

            habilidadeinicial.Text = _ht;
            energiainicial.Text = _et;
            sorteinicial.Text = _st;

            //phabilidade = habilidadeinicial.Text;

            

            //_folha.habilidadeLabel.Text = phabilidade;
            //_folha.energiaLabel.Text = penergia;
            //_folha.sorteLabel.Text = psorte;

            button1.Enabled = true;

            //_folha.ShowDialog();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Folha _folha = new Folha();

            _folha.habilidadeLabel.Text = _ht;
            _folha.energiaLabel.Text = _et;
            _folha.sorteLabel.Text = _st;
            _folha.ShowDialog();
        }

        private void habilidadeinicial_TextChanged(object sender, EventArgs e)
        {
            phabilidade = habilidadeinicial.Text;
        }

        private void sorte_TextChanged(object sender, EventArgs e)
        {
            psorte = sorteinicial.Text;
        }

        private void energiainicial_TextChanged(object sender, EventArgs e)
        {
            penergia = energiainicial.Text;
        }
    }
}
