﻿namespace TemploDoTerror
{
    partial class Folha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRoll = new System.Windows.Forms.Button();
            this.rolllabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.habilidadeLabel = new System.Windows.Forms.Label();
            this.energiaLabel = new System.Windows.Forms.Label();
            this.sorteLabel = new System.Windows.Forms.Label();
            this.die1 = new System.Windows.Forms.Label();
            this.die2 = new System.Windows.Forms.Label();
            this.sacoLabel = new System.Windows.Forms.Label();
            this.ouroLabel = new System.Windows.Forms.Label();
            this.encantosLabel = new System.Windows.Forms.Label();
            this.provisoesLabel = new System.Windows.Forms.Label();
            this.monstroLabel = new System.Windows.Forms.Label();
            this.habilidademonstroLabel = new System.Windows.Forms.Label();
            this.energiamonstroLabel = new System.Windows.Forms.Label();
            this.abrirPortascheck = new System.Windows.Forms.CheckBox();
            this.sonocheck = new System.Windows.Forms.CheckBox();
            this.flechacheck = new System.Windows.Forms.CheckBox();
            this.idiomacheck = new System.Windows.Forms.CheckBox();
            this.fogocheck = new System.Windows.Forms.CheckBox();
            this.lercheck = new System.Windows.Forms.CheckBox();
            this.luzcheck = new System.Windows.Forms.CheckBox();
            this.saltarcheck = new System.Windows.Forms.CheckBox();
            this.aguacheck = new System.Windows.Forms.CheckBox();
            this.armadilhascheck = new System.Windows.Forms.CheckBox();
            this.ourol = new System.Windows.Forms.Label();
            this.provl = new System.Windows.Forms.Label();
            this.ponte23 = new System.Windows.Forms.Button();
            this.port213 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.lblCriaturaHab = new System.Windows.Forms.Label();
            this.lblCriaturaE = new System.Windows.Forms.Label();
            this.lblCriaturaAtaque = new System.Windows.Forms.Label();
            this.lblCriauraFataque = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnRoll
            // 
            this.btnRoll.Location = new System.Drawing.Point(16, 328);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(75, 23);
            this.btnRoll.TabIndex = 6;
            this.btnRoll.Text = "Roll";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.RollDice);
            // 
            // rolllabel
            // 
            this.rolllabel.AutoSize = true;
            this.rolllabel.Location = new System.Drawing.Point(97, 338);
            this.rolllabel.Name = "rolllabel";
            this.rolllabel.Size = new System.Drawing.Size(0, 13);
            this.rolllabel.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "HABILIDADE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(91, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "ENERGIA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(153, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "SORTE";
            // 
            // habilidadeLabel
            // 
            this.habilidadeLabel.AutoSize = true;
            this.habilidadeLabel.Location = new System.Drawing.Point(32, 35);
            this.habilidadeLabel.Name = "habilidadeLabel";
            this.habilidadeLabel.Size = new System.Drawing.Size(35, 13);
            this.habilidadeLabel.TabIndex = 14;
            this.habilidadeLabel.Text = "label4";
            this.habilidadeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // energiaLabel
            // 
            this.energiaLabel.AutoSize = true;
            this.energiaLabel.Location = new System.Drawing.Point(97, 35);
            this.energiaLabel.Name = "energiaLabel";
            this.energiaLabel.Size = new System.Drawing.Size(35, 13);
            this.energiaLabel.TabIndex = 15;
            this.energiaLabel.Text = "label4";
            this.energiaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sorteLabel
            // 
            this.sorteLabel.AutoSize = true;
            this.sorteLabel.Location = new System.Drawing.Point(153, 35);
            this.sorteLabel.Name = "sorteLabel";
            this.sorteLabel.Size = new System.Drawing.Size(35, 13);
            this.sorteLabel.TabIndex = 16;
            this.sorteLabel.Text = "label4";
            this.sorteLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // die1
            // 
            this.die1.AutoSize = true;
            this.die1.Location = new System.Drawing.Point(16, 358);
            this.die1.Name = "die1";
            this.die1.Size = new System.Drawing.Size(0, 13);
            this.die1.TabIndex = 17;
            // 
            // die2
            // 
            this.die2.AutoSize = true;
            this.die2.Location = new System.Drawing.Point(55, 357);
            this.die2.Name = "die2";
            this.die2.Size = new System.Drawing.Size(0, 13);
            this.die2.TabIndex = 18;
            // 
            // sacoLabel
            // 
            this.sacoLabel.AutoSize = true;
            this.sacoLabel.Location = new System.Drawing.Point(16, 73);
            this.sacoLabel.Name = "sacoLabel";
            this.sacoLabel.Size = new System.Drawing.Size(36, 13);
            this.sacoLabel.TabIndex = 19;
            this.sacoLabel.Text = "SACO";
            // 
            // ouroLabel
            // 
            this.ouroLabel.AutoSize = true;
            this.ouroLabel.Location = new System.Drawing.Point(72, 73);
            this.ouroLabel.Name = "ouroLabel";
            this.ouroLabel.Size = new System.Drawing.Size(39, 13);
            this.ouroLabel.TabIndex = 20;
            this.ouroLabel.Text = "OURO";
            // 
            // encantosLabel
            // 
            this.encantosLabel.AutoSize = true;
            this.encantosLabel.Location = new System.Drawing.Point(131, 73);
            this.encantosLabel.Name = "encantosLabel";
            this.encantosLabel.Size = new System.Drawing.Size(66, 13);
            this.encantosLabel.TabIndex = 21;
            this.encantosLabel.Text = "ENCANTOS";
            // 
            // provisoesLabel
            // 
            this.provisoesLabel.AutoSize = true;
            this.provisoesLabel.Location = new System.Drawing.Point(59, 118);
            this.provisoesLabel.Name = "provisoesLabel";
            this.provisoesLabel.Size = new System.Drawing.Size(69, 13);
            this.provisoesLabel.TabIndex = 22;
            this.provisoesLabel.Text = "PROVISÕES";
            // 
            // monstroLabel
            // 
            this.monstroLabel.AutoSize = true;
            this.monstroLabel.Location = new System.Drawing.Point(360, 13);
            this.monstroLabel.Name = "monstroLabel";
            this.monstroLabel.Size = new System.Drawing.Size(62, 13);
            this.monstroLabel.TabIndex = 23;
            this.monstroLabel.Text = "CRIATURA";
            // 
            // habilidademonstroLabel
            // 
            this.habilidademonstroLabel.AutoSize = true;
            this.habilidademonstroLabel.Location = new System.Drawing.Point(318, 35);
            this.habilidademonstroLabel.Name = "habilidademonstroLabel";
            this.habilidademonstroLabel.Size = new System.Drawing.Size(71, 13);
            this.habilidademonstroLabel.TabIndex = 24;
            this.habilidademonstroLabel.Text = "HABILIDADE";
            // 
            // energiamonstroLabel
            // 
            this.energiamonstroLabel.AutoSize = true;
            this.energiamonstroLabel.Location = new System.Drawing.Point(395, 35);
            this.energiamonstroLabel.Name = "energiamonstroLabel";
            this.energiamonstroLabel.Size = new System.Drawing.Size(55, 13);
            this.energiamonstroLabel.TabIndex = 25;
            this.energiamonstroLabel.Text = "ENERGIA";
            // 
            // abrirPortascheck
            // 
            this.abrirPortascheck.AutoSize = true;
            this.abrirPortascheck.Location = new System.Drawing.Point(134, 90);
            this.abrirPortascheck.Name = "abrirPortascheck";
            this.abrirPortascheck.Size = new System.Drawing.Size(80, 17);
            this.abrirPortascheck.TabIndex = 26;
            this.abrirPortascheck.Text = "Abrir Portas";
            this.abrirPortascheck.UseVisualStyleBackColor = true;
            this.abrirPortascheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // sonocheck
            // 
            this.sonocheck.AutoSize = true;
            this.sonocheck.Location = new System.Drawing.Point(134, 114);
            this.sonocheck.Name = "sonocheck";
            this.sonocheck.Size = new System.Drawing.Size(110, 17);
            this.sonocheck.TabIndex = 27;
            this.sonocheck.Text = "Sono de Criaturas";
            this.sonocheck.UseVisualStyleBackColor = true;
            this.sonocheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // flechacheck
            // 
            this.flechacheck.AutoSize = true;
            this.flechacheck.Location = new System.Drawing.Point(134, 138);
            this.flechacheck.Name = "flechacheck";
            this.flechacheck.Size = new System.Drawing.Size(96, 17);
            this.flechacheck.TabIndex = 28;
            this.flechacheck.Text = "Flecha Mágica";
            this.flechacheck.UseVisualStyleBackColor = true;
            this.flechacheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // idiomacheck
            // 
            this.idiomacheck.AutoSize = true;
            this.idiomacheck.Location = new System.Drawing.Point(134, 161);
            this.idiomacheck.Name = "idiomacheck";
            this.idiomacheck.Size = new System.Drawing.Size(57, 17);
            this.idiomacheck.TabIndex = 29;
            this.idiomacheck.Text = "Idioma";
            this.idiomacheck.UseVisualStyleBackColor = true;
            this.idiomacheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // fogocheck
            // 
            this.fogocheck.AutoSize = true;
            this.fogocheck.Location = new System.Drawing.Point(134, 233);
            this.fogocheck.Name = "fogocheck";
            this.fogocheck.Size = new System.Drawing.Size(50, 17);
            this.fogocheck.TabIndex = 30;
            this.fogocheck.Text = "Fogo";
            this.fogocheck.UseVisualStyleBackColor = true;
            this.fogocheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // lercheck
            // 
            this.lercheck.AutoSize = true;
            this.lercheck.Location = new System.Drawing.Point(134, 186);
            this.lercheck.Name = "lercheck";
            this.lercheck.Size = new System.Drawing.Size(88, 17);
            this.lercheck.TabIndex = 31;
            this.lercheck.Text = "Ler Símbolos";
            this.lercheck.UseVisualStyleBackColor = true;
            this.lercheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // luzcheck
            // 
            this.luzcheck.AutoSize = true;
            this.luzcheck.Location = new System.Drawing.Point(134, 210);
            this.luzcheck.Name = "luzcheck";
            this.luzcheck.Size = new System.Drawing.Size(43, 17);
            this.luzcheck.TabIndex = 32;
            this.luzcheck.Text = "Luz";
            this.luzcheck.UseVisualStyleBackColor = true;
            this.luzcheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // saltarcheck
            // 
            this.saltarcheck.AutoSize = true;
            this.saltarcheck.Location = new System.Drawing.Point(134, 257);
            this.saltarcheck.Name = "saltarcheck";
            this.saltarcheck.Size = new System.Drawing.Size(53, 17);
            this.saltarcheck.TabIndex = 33;
            this.saltarcheck.Text = "Saltar";
            this.saltarcheck.UseVisualStyleBackColor = true;
            this.saltarcheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // aguacheck
            // 
            this.aguacheck.AutoSize = true;
            this.aguacheck.Location = new System.Drawing.Point(134, 305);
            this.aguacheck.Name = "aguacheck";
            this.aguacheck.Size = new System.Drawing.Size(74, 17);
            this.aguacheck.TabIndex = 34;
            this.aguacheck.Text = "Criar água";
            this.aguacheck.UseVisualStyleBackColor = true;
            this.aguacheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // armadilhascheck
            // 
            this.armadilhascheck.AutoSize = true;
            this.armadilhascheck.Location = new System.Drawing.Point(134, 280);
            this.armadilhascheck.Name = "armadilhascheck";
            this.armadilhascheck.Size = new System.Drawing.Size(115, 17);
            this.armadilhascheck.TabIndex = 35;
            this.armadilhascheck.Text = "Detetar Armadilhas";
            this.armadilhascheck.UseVisualStyleBackColor = true;
            this.armadilhascheck.CheckedChanged += new System.EventHandler(this.OnCheckedChanged);
            // 
            // ourol
            // 
            this.ourol.AutoSize = true;
            this.ourol.Location = new System.Drawing.Point(84, 86);
            this.ourol.Name = "ourol";
            this.ourol.Size = new System.Drawing.Size(0, 13);
            this.ourol.TabIndex = 36;
            // 
            // provl
            // 
            this.provl.AutoSize = true;
            this.provl.Location = new System.Drawing.Point(84, 142);
            this.provl.Name = "provl";
            this.provl.Size = new System.Drawing.Size(19, 13);
            this.provl.TabIndex = 37;
            this.provl.Text = "10";
            // 
            // ponte23
            // 
            this.ponte23.Location = new System.Drawing.Point(174, 325);
            this.ponte23.Name = "ponte23";
            this.ponte23.Size = new System.Drawing.Size(75, 23);
            this.ponte23.TabIndex = 51;
            // 
            // port213
            // 
            this.port213.Location = new System.Drawing.Point(174, 354);
            this.port213.Name = "port213";
            this.port213.Size = new System.Drawing.Size(75, 23);
            this.port213.TabIndex = 50;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(244, 90);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(43, 17);
            this.radioButton1.TabIndex = 40;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Info";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(244, 113);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(43, 17);
            this.radioButton2.TabIndex = 41;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Info";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(244, 138);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(43, 17);
            this.radioButton3.TabIndex = 42;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Info";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(244, 161);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(43, 17);
            this.radioButton4.TabIndex = 43;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Info";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(244, 185);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(43, 17);
            this.radioButton5.TabIndex = 44;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Info";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(244, 209);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(43, 17);
            this.radioButton6.TabIndex = 45;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Info";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(244, 233);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(43, 17);
            this.radioButton7.TabIndex = 46;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Info";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(244, 257);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(43, 17);
            this.radioButton8.TabIndex = 47;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Info";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(244, 281);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(43, 17);
            this.radioButton9.TabIndex = 48;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Info";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(244, 305);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(43, 17);
            this.radioButton10.TabIndex = 49;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "Info";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // lblCriaturaHab
            // 
            this.lblCriaturaHab.AutoSize = true;
            this.lblCriaturaHab.Location = new System.Drawing.Point(335, 48);
            this.lblCriaturaHab.Name = "lblCriaturaHab";
            this.lblCriaturaHab.Size = new System.Drawing.Size(0, 13);
            this.lblCriaturaHab.TabIndex = 52;
            // 
            // lblCriaturaE
            // 
            this.lblCriaturaE.AutoSize = true;
            this.lblCriaturaE.Location = new System.Drawing.Point(404, 48);
            this.lblCriaturaE.Name = "lblCriaturaE";
            this.lblCriaturaE.Size = new System.Drawing.Size(0, 13);
            this.lblCriaturaE.TabIndex = 53;
            // 
            // lblCriaturaAtaque
            // 
            this.lblCriaturaAtaque.AutoSize = true;
            this.lblCriaturaAtaque.Location = new System.Drawing.Point(457, 35);
            this.lblCriaturaAtaque.Name = "lblCriaturaAtaque";
            this.lblCriaturaAtaque.Size = new System.Drawing.Size(108, 13);
            this.lblCriaturaAtaque.TabIndex = 54;
            this.lblCriaturaAtaque.Text = "FORÇA DE ATAQUE";
            // 
            // lblCriauraFataque
            // 
            this.lblCriauraFataque.AutoSize = true;
            this.lblCriauraFataque.Location = new System.Drawing.Point(495, 48);
            this.lblCriauraFataque.Name = "lblCriauraFataque";
            this.lblCriauraFataque.Size = new System.Drawing.Size(0, 13);
            this.lblCriauraFataque.TabIndex = 55;
            // 
            // Folha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 389);
            this.Controls.Add(this.lblCriauraFataque);
            this.Controls.Add(this.lblCriaturaAtaque);
            this.Controls.Add(this.lblCriaturaE);
            this.Controls.Add(this.lblCriaturaHab);
            this.Controls.Add(this.radioButton10);
            this.Controls.Add(this.radioButton9);
            this.Controls.Add(this.radioButton8);
            this.Controls.Add(this.radioButton7);
            this.Controls.Add(this.radioButton6);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.port213);
            this.Controls.Add(this.ponte23);
            this.Controls.Add(this.provl);
            this.Controls.Add(this.ourol);
            this.Controls.Add(this.armadilhascheck);
            this.Controls.Add(this.aguacheck);
            this.Controls.Add(this.saltarcheck);
            this.Controls.Add(this.luzcheck);
            this.Controls.Add(this.lercheck);
            this.Controls.Add(this.fogocheck);
            this.Controls.Add(this.idiomacheck);
            this.Controls.Add(this.flechacheck);
            this.Controls.Add(this.sonocheck);
            this.Controls.Add(this.abrirPortascheck);
            this.Controls.Add(this.energiamonstroLabel);
            this.Controls.Add(this.habilidademonstroLabel);
            this.Controls.Add(this.monstroLabel);
            this.Controls.Add(this.provisoesLabel);
            this.Controls.Add(this.encantosLabel);
            this.Controls.Add(this.ouroLabel);
            this.Controls.Add(this.sacoLabel);
            this.Controls.Add(this.die2);
            this.Controls.Add(this.die1);
            this.Controls.Add(this.sorteLabel);
            this.Controls.Add(this.energiaLabel);
            this.Controls.Add(this.habilidadeLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rolllabel);
            this.Controls.Add(this.btnRoll);
            this.Name = "Folha";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Folha_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.Label rolllabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label habilidadeLabel;
        public System.Windows.Forms.Label energiaLabel;
        public System.Windows.Forms.Label sorteLabel;
        public System.Windows.Forms.Label die1;
        public System.Windows.Forms.Label die2;
        private System.Windows.Forms.Label sacoLabel;
        private System.Windows.Forms.Label ouroLabel;
        private System.Windows.Forms.Label encantosLabel;
        private System.Windows.Forms.Label provisoesLabel;
        private System.Windows.Forms.Label monstroLabel;
        private System.Windows.Forms.Label habilidademonstroLabel;
        private System.Windows.Forms.Label energiamonstroLabel;
        private System.Windows.Forms.CheckBox abrirPortascheck;
        private System.Windows.Forms.CheckBox sonocheck;
        private System.Windows.Forms.CheckBox flechacheck;
        private System.Windows.Forms.CheckBox idiomacheck;
        private System.Windows.Forms.CheckBox fogocheck;
        private System.Windows.Forms.CheckBox lercheck;
        private System.Windows.Forms.CheckBox luzcheck;
        private System.Windows.Forms.CheckBox saltarcheck;
        private System.Windows.Forms.CheckBox aguacheck;
        private System.Windows.Forms.CheckBox armadilhascheck;
        private System.Windows.Forms.Label ourol;
        private System.Windows.Forms.Label provl;
        public System.Windows.Forms.Button ponte23;
        public System.Windows.Forms.Button port213;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.Label lblCriaturaHab;
        private System.Windows.Forms.Label lblCriaturaE;
        private System.Windows.Forms.Label lblCriaturaAtaque;
        private System.Windows.Forms.Label lblCriauraFataque;
    }
}