﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemploDoTerror.Models
{
    class ElfoNegro : Criatura
    {
        //Folha _folhaElf = new Folha(); //Para aceder aos valores dos dados

        private int _fataque;

        public ElfoNegro(string tipo, int hab, int en) : base(tipo, hab, en)
        {
            //this._fataque = fa;
        }

        //public int Roll(int hab) 
        //{
        //    int _valDie1 = TemploDoTerror.Controller.dice.Roll();
        //    int _valDie2 = TemploDoTerror.Controller.dice.Roll();
            
        //    die1.Text = _valDie1.ToString();
        //    die2.Text = _valDie2.ToString();

        //    int _fa = _valDie1 + _valDie2;
        //    int _fat = _fa + hab;
            
        //    return _fat;
        //}
    }
}
