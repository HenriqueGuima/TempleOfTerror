﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TemploDoTerror.Controller
{
    public class lib
    {
        public static int IndiceHabilidade() 
        {
            int IH = TemploDoTerror.Controller.dice.Roll();
            return IH + 6;
        }

        public static int IndiceEnergia()
        {
            int IE = TemploDoTerror.Controller.dice.Roll();
            return IE + 12;
        }

        public static int IndiceSorte()
        {
            int IS = TemploDoTerror.Controller.dice.Roll();
            return IS + 6;
        }

    }
}
