﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.SQLite;
using Dapper;

namespace TemploDoTerror.Visual
{
    class Start
    {

        //public static List<PassosModel> Load1()
        //{
        //    using (IDbConnection cnn = new SQLiteConnection(PassosLib.LoadConnectionString()))
        //    {
        //        var output = cnn.Query<PassosModel>("select * from Passos where Numero = 1", new DynamicParameters());
        //        //Console.Write(output);
        //        return output.ToList();
        //    }
        //}

        //public static void SQLoad1()
        //{
        //    using (IDbConnection cnn = new SQLiteConnection(PassosLib.LoadConnectionString()))
        //    {
        //        var output = cnn.Query<PassosModel>("select * from Passos where Numero = 0", new DynamicParameters());
        //        Console.Write(output);
        //        //return output.ToList();
        //    }

        //}

        //Folha _folha = new Folha();

        public static void Inicio()
        {
            string read = File.ReadAllText(@"C:\Users\HenriqueAlbertoBarro\source\repos\TemploDoTerror\Visual\TextFiles\intro.txt");
            Console.Write(read);
        }
        public static void Dicas()
        {
            Console.Clear();
            string read = File.ReadAllText(@"C:\Users\HenriqueAlbertoBarro\source\repos\TemploDoTerror\Visual\TextFiles\Dicas.txt");
            Console.Write(read);
        }
        public static void Historia()
        {
            Console.Clear();
            string read = File.ReadAllText(@"C:\Users\HenriqueAlbertoBarro\source\repos\TemploDoTerror\Visual\TextFiles\Historia.txt");
            Console.Write(read);
        }

        
    }
}
