﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemploDoTerror.Controller
{
    public class dice
    {

        private static Random rnd = new Random();
        public static int Roll()
        {
            
            int val = rnd.Next(1, 8);

            return val;
        }
    }
}
