﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemploDoTerror
{
    class PassosLib
    {

        public static List<PassosModel> Load1(int nr)
        {
            //Console.Clear();

            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<PassosModel>("select * from Passos where Numero=" + nr + "", new DynamicParameters());

                return output.ToList();
            }

        }

        public static string LoadConnectionString (string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }
}
