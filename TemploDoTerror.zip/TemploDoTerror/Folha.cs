﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TemploDoTerror
{
    public partial class Folha : Form
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool AllocConsole();

        //public string die1P { get {return die1.Text;} set { die1.Text = value; } }

        public List<PassosModel> _passos = new List<PassosModel>();

        Models.ElfoNegro ElfoNegro1 = new Models.ElfoNegro("Elfo Negro 1", 5, 6);
        Models.ElfoNegro ElfoNegro2 = new Models.ElfoNegro("Elfo Negro 2", 6, 5);

        public Folha()
        {
            InitializeComponent();

            //ponte23.Visible = true;
            //ponte23.Text = "";
            //port213.Visible = true;
            //port213.Text = "";

            ponte23.Visible = false;
            port213.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            TemploDoTerror.Controller.dice.Roll();

            int roll = TemploDoTerror.Controller.dice.Roll();

            rolllabel.Text = roll.ToString();
        }

        #region DLLs
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        static extern IntPtr FindWindowByCaption(IntPtr zeroOnly, string lpWindowName);
        #endregion

        public void CarregaTexto(int nr)
        {
            Console.Clear();

            _passos = PassosLib.Load1(nr);

            foreach (var passo in _passos)
            {
                Console.WriteLine(passo);
            }
        }

        //private bool buttonIsClicked = false;
        private void Folha_Load(object sender, EventArgs e)
        {
            btnRoll.Visible = false;
            #region JANELA
            //AllocConsole();
            string originalTitle = Console.Title;
            string uniqueTitle = Guid.NewGuid().ToString();
            Console.Title = uniqueTitle;
            Thread.Sleep(50);
            IntPtr handle = FindWindowByCaption(IntPtr.Zero, uniqueTitle);

            if (handle == IntPtr.Zero)
            {
                Console.WriteLine("Oops, cant find main window.");
                return;
            }
            Console.Title = originalTitle;

            #endregion

            #region MOSTRA DADOS
            while (true)
            {
                //PassosModel p = new PassosModel();
                //Console.WriteLine(SetForegroundWindow(handle));

                //TemploDoTerror.Visual.Start.Inicio();
                //Console.ReadKey();
                //TemploDoTerror.Visual.Start.Dicas();
                //Console.ReadKey();
                //TemploDoTerror.Visual.Start.Historia();
                //Console.ReadKey();
                //CarregaTexto(1);
                //Console.ReadKey();

                //string texto = p.Texto;

                //Console.WriteLine(p.Texto);

                //Console.ReadKey();

                break;
            }

            #endregion

        }

        void Ponte(object sender, EventArgs e)
        {
            // First Button Clicked
            // Creates buttons on stage 2

            this.Controls.Remove((Button)Controls["btn0"]);
            this.Controls.Remove((Button)Controls["btn1"]);

            for (int i = 0; i < 2; i++)
            {
                Button button = new Button();
                button.AutoSize = true;
                button.Name = "btn" + i;
                
                switch (i)
                {
                    case 0:
                        button.Click += new EventHandler(Fumo);
                        button.Text = "Fumo";
                        button.Location = new Point(157, 328);
                        CarregaTexto(316);
                        break;
                    case 1:
                        button.Click += new EventHandler(Sul159);
                        button.Text = "Ir para Sul";
                        button.Location = new Point(169, 357);
                        CarregaTexto(159);
                        break;
                }

                this.Controls.Add(button);
            }
        }

        private void Sul159(object sender, EventArgs e)
        {

        }

        private void Fumo(object sender, EventArgs e)
        {
            this.Controls.Remove((Button)Controls["btn0"]);
            this.Controls.Remove((Button)Controls["btn1"]);

            for (int i = 0; i < 2; i++)
            {
                Button button = new Button();
                button.AutoSize = true;
                button.Name = "btn" + i;


                switch (i)
                {
                    case 0:
                        button.Click += new EventHandler(Elfos);
                        button.Text = "Combater com os Elfos Negros";
                        button.Location = new Point(157, 328);
                        CarregaTexto(113);
                        break;
                    case 1:
                        button.Click += new EventHandler(Sul285);
                        button.Text = "Continuar para Sul";
                        button.Location = new Point(169, 357);
                        CarregaTexto(285);
                        break;
                }

                this.Controls.Add(button);
            }
        }

        private void Sul285(object sender, EventArgs e)
        {

        }

        private void Elfos(object sender, EventArgs e)
        {
            this.Controls.Remove((Button)Controls["btn0"]);
            this.Controls.Remove((Button)Controls["btn1"]);

            //btnRoll.Enabled = true;

            Button button = new Button();
            button.AutoSize = true;
            button.Name = "CombateRollElfos";
            button.Text = "Roll";
            button.Location = new Point(16, 328);
            button.Visible = true;
            this.Controls.Add(button);


            //Botão par ao jogador
            Button buttonP = new Button();
            buttonP.AutoSize = true;
            buttonP.Name = "CombatePlayer";
            buttonP.Text = "Roll";
            buttonP.Location = new Point(16, 328);
            buttonP.Visible = true;
            this.Controls.Add(button);

            button.Click += new EventHandler(RollDiceElf);

            lblCriaturaHab.Text = ElfoNegro1.Habilidade.ToString();
            lblCriaturaE.Text = ElfoNegro1.Energia.ToString();

            this.Controls.Remove((Button)Controls["CombateRollElfos"]);

            buttonP.Click += new EventHandler(RollMe);
        }

        void Blacksand(object sender, EventArgs e)
        {
            // Second Button Clicked
        }

        void ButtonClick3(object sender, EventArgs e)
        {
            // Third Button Clicked
        }

        void ButtonClick4(object sender, EventArgs e)
        {
            // Fourth Button Clicked
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Roll dice for dark elves
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RollDiceElf(object sender, EventArgs e)
        {
            lblCriauraFataque.Text = Roll(5, 6).ToString();
            //_fat.ToString();
            ((Button)sender).Click -= new EventHandler(RollDiceElf);
            ((Button)sender).Enabled = false;
        }

        private void RollMe(object sender, EventArgs e)
        {
            Roll(Controller.lib.IndiceHabilidade(), Controller.lib.IndiceEnergia());
            ((Button)sender).Click -= new EventHandler(RollMe);
            ((Button)sender).Enabled = false;
        }

        public int RollPlayer(int hab, int en)
        {
            int _valDie1 = TemploDoTerror.Controller.dice.Roll();
            int _valDie2 = TemploDoTerror.Controller.dice.Roll();

            die1.Text = _valDie1.ToString();
            die2.Text = _valDie2.ToString();

            int _fa = _valDie1 + _valDie2;
            int _fat = _fa + hab;

            return _fat;
        }

        public int Roll(int hab, int en)
        {
            int _valDie1 = TemploDoTerror.Controller.dice.Roll();
            int _valDie2 = TemploDoTerror.Controller.dice.Roll();

            die1.Text = _valDie1.ToString();
            die2.Text = _valDie2.ToString();

            int _fa = _valDie1 + _valDie2;
            int _fat = _fa + hab;

            return _fat;
        }

        private void RollDice(object sender, EventArgs e)
        {
            int _valDie1 = TemploDoTerror.Controller.dice.Roll();
            int _valDie2 = TemploDoTerror.Controller.dice.Roll();

            die1.Text = _valDie1.ToString();
            die2.Text = _valDie2.ToString();
        }

        #region CHECK
        private void abrirPortascheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private int checkCounter;

        private void OnCheckedChanged (object sender, EventArgs e)
        {
            CheckBox box = (CheckBox) sender;

            if (box.Checked)
            {
                checkCounter++;
            }
            else
            {
                checkCounter--;
            }

            if (checkCounter == 4)
            {
                
                //box.Checked = false;
                sonocheck.Enabled = false;
                flechacheck.Enabled = false;
                aguacheck.Enabled = false;
                abrirPortascheck.Enabled = false;
                idiomacheck.Enabled = false;
                fogocheck.Enabled = false;
                lercheck.Enabled = false;
                luzcheck.Enabled = false;
                saltarcheck.Enabled = false;
                armadilhascheck.Enabled = false;

                CarregaTexto(180);

                radioButton1.Visible = false;
                radioButton2.Visible = false;
                radioButton3.Visible = false;
                radioButton4.Visible = false;
                radioButton5.Visible = false;
                radioButton6.Visible = false;
                radioButton7.Visible = false;
                radioButton8.Visible = false;
                radioButton9.Visible = false;
                radioButton10.Visible = false;

                MessageBox.Show("Limite de 4 encantos atingido!", "Ok");

                //Creates buttons on stage one

                for (int i = 0; i < 2; i++)
                {
                    Button button = new Button();
                    button.AutoSize = true;
                    button.Name = "btn" + i;

                    switch (i)
                    {
                        case 0:
                            button.Click += new EventHandler(Ponte);
                            button.Text = "Ponte";
                            button.Location = new Point(157, 328);
                            break;
                        case 1:
                            button.Click += new EventHandler(Blacksand);
                            button.Text = "Blacksand";
                            button.Location = new Point(169, 357);
                            break;
                    }

                    this.Controls.Add(button);
                }

            }
        }

        private void sonocheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void flechacheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void idiomacheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void fogocheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lercheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void luzcheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void saltarcheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void aguacheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void armadilhascheck_CheckedChanged(object sender, EventArgs e)
        {

        }

        //public bool button1WasClicked = false;
       

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //string doze = string(TemploDoTerror.Visual.Start.Doze());
            //MessageBox.Show(, "ok");

            CarregaTexto(12);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(58);
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(136);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(194);
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(391);
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(223);
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(264);
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(301);
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(342);
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            CarregaTexto(367);
        }

        #endregion

        
    }
}
