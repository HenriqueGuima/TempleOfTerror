﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemploDoTerror
{
    public class PassosModel
    {
        public int Numero{ get; set; }
        public string Texto{ get; set; }

        public string PrintT{ get { return $"{Texto}"; } }

        public override string ToString()
        {
            return $"{Texto}";
        }
    }
}
