﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemploDoTerror.Models
{
    class Criatura
    {
        private string _tipo;
        private int _habilidade;
        private int _energia;
        //private int _fataque;

        //public string Dados { get {return string.Format ("\nTipo: " + _tipo + "\nHabilidade: " +_habilidade+ "\nEnergia: "+_energia); }}
        public string Habilidade { get {return string.Format ("" + _habilidade); } }
        public string Energia { get { return string.Format("" + _energia); } }
        public Criatura (string tipo, int hab, int en)
        {
            this._tipo = tipo;
            this._habilidade = hab;
            this._energia = en;
            //this._fataque = fataque;
        }
    }
}
